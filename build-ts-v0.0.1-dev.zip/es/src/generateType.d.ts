import type { BaseOptions } from '../type/build-typescript';
export declare const generateTypesDefinitions: (baseOptions: BaseOptions) => Promise<void>;
