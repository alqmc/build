import type { BaseOptions, PluginOptions } from '../type/build-typescript';
export declare const generatePlugin: (baseOptions: BaseOptions, pluginOptions?: PluginOptions) => import("rollup").Plugin[];
