import type { InputOption } from 'rollup';
interface TypescriptOptions {
    input: InputOption;
    outPutPath: string;
    enterPath: string;
    pkgPath: string;
    tsConfigPath: string;
}
export declare const buildTypescriptLib: (options: TypescriptOptions) => Promise<void>;
export {};
