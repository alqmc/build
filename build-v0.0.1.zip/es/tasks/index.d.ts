import { buildTypescriptLib } from './typescriptLib';
import { buildVueLib } from './vueLib';
export { buildTypescriptLib, buildVueLib };
