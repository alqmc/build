## @alqmc/build-typescript

typescript lib打包库