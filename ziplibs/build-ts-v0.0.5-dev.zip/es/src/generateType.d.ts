import type { BaseOptions, BuildProduct } from '../type/build-typescript';
export declare const generateTypesDefinitions: (baseOptions: BaseOptions, buildProduct: BuildProduct[], onlyOutput: boolean) => Promise<void>;
