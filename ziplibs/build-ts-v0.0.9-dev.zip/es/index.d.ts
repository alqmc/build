import type { DefineTsConfig } from './type/build-typescript';
export * from './type/build-typescript';
export declare const buildTypescriptLib: ({ baseOptions, pluginOptions, externalOptions, extraOptions, buildProduct, pureOutput, includePackages, }: DefineTsConfig) => Promise<void>;
