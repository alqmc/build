import type { BaseOptions, BuildProduct } from '../type/build-vue';
export declare const generateTypesDefinitions: (baseOptions: BaseOptions, buildProduct: BuildProduct[], onlyOutput: boolean) => Promise<void>;
