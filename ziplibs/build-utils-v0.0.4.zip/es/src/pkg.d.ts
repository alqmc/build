import type { ProjectManifest } from '@pnpm/types';
export declare const getPackageDependencies: (pkgPath: string) => Record<'dependencies' | 'peerDependencies', string[]>;
export declare const getPackageManifest: (pkgPath: string) => ProjectManifest;
export declare const getExternal: (options: {
    outputPackage: string;
    extraExternal?: string[];
    includePackages: string[];
}) => Promise<(id: string) => boolean>;
