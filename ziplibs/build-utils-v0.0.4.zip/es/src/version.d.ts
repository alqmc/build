export interface VersionOptions {
    targetPkgPath: string | string[];
}
export declare const updateVersion: (versionOptions: VersionOptions) => Promise<Error | void>;
