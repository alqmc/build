import type { Plugin } from 'rollup';
import type { BaseOptions, MergeType, PluginOptions } from '../type/build-typescript';
export declare const generatePlugin: (baseOptions: BaseOptions, pluginOptions?: PluginOptions) => Plugin[];
export declare const mergePlugins: (defaultPlugins: Plugin[], propsPlugins: Plugin[], mergeType: MergeType) => Plugin[];
