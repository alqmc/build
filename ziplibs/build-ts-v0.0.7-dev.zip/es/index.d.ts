import type { DefineLibConfig } from './type/build-typescript';
export * from './type/build-typescript';
export declare const buildTypescriptLib: ({ baseOptions, pluginOptions, externalOptions, extraOptions, buildProduct, pureOutput, }: DefineLibConfig) => Promise<void>;
