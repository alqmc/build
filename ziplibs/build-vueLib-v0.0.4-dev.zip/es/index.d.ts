import type { DefineLibConfig } from './type/build-vue';
export declare const buildVueLib: ({ baseOptions, pluginOptions, externalOptions, extraOptions, buildProduct, }: DefineLibConfig) => Promise<void>;
