import type { DefineVueConfig } from './type/build-vue';
export declare const buildVueLib: ({ baseOptions, pluginOptions, externalOptions, extraOptions, buildProduct, pureOutput, includePackages, }: DefineVueConfig) => Promise<void>;
export * from './type/build-vue';
