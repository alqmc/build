import type { Options } from 'prettier';
export declare const formatCode: (code: string, prettierOptions?: Options) => string;
