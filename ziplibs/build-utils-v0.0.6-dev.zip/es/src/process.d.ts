export declare const run: (command: string, dir?: string) => Promise<void>;
export declare const withTask: <T extends import("undertaker").TaskFunction>(name: string, fn: T) => T & {
    displayName: string;
};
