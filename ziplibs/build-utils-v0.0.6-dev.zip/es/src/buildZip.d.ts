export interface ZipOptions {
    fileName: string;
    enterPath: string;
    outPath: string;
    format?: 'zip' | 'tar';
}
export declare const createZip: (zipOptions: ZipOptions) => Promise<void>;
